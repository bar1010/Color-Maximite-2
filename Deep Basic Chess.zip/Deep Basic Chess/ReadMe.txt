Deep Basic by Thomas McBurney  2003

Email - tommyinoz@yahoo.com
Web Site - www.zeta.org.au/~tommy


Commands
========

NEW
	Start new game.


FLIP
	Rotate the board 180 degrees.

BACK
	Take back one move.  


SWAP
	Swap sides.  Deep BASIC will immediately start calculating next move for side to move.

GO
	Does exactly the same as Swap.  


TIME
	The average amount of time in seconds Deep BASIC is allowed to "think".  If you enter
	0 (zero) seconds, Deep BASIC will continue to think until interrupted.


FEN
	Use this to set up a board position. Deep BASIC will interpret the FEN (Forsyth Edwards Notation) 
	string found in the FEN.IN file located in the same directory as Deep BASIC.         


AUTO
	Deep BASIC will play itself until game is over.


TEST 
	Simple benchmark test.  The test results will display NPS (Nodes per second) and time taken.
	The benchmark test results are compared to an AMD Athlon 650.


<SPACE>
	Press the space bar while Deep BASIC is thinking to force Deep BASIC to move now.  


QUIT
	Exit out of program.
 